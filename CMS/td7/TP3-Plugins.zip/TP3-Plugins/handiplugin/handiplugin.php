<?php
/**
* Plugin Name: Plugin Handi
* Description: Mon premier plugin WordPress
* Version: 1.0
*/


session_start();

class HandiPlugin
{

	public function __construct(){
		add_filter('the_title', array($this, 'plugin_handi_init'));	
        add_action('admin_menu', array($this, 'plugin_handi_setup_menu'));		
	}
	
	function plugin_handi_setup_menu(){
		// titre, item, role, slug, fonction
		add_menu_page('Mon Plugin Handi', 'Plugin Handi', 'administrator', 'pluginHandi', array($this,'plugin_handi_contenu_page'));
	}
	
	function plugin_handi_contenu_page(){	
		echo '
		     <h1>  Mon Plugin Handi </h1>
			 <h3>  Ce plugin permet d\'ajouter un texte suplementaire à tous les titres</h3>
		     <form action="" method="post">
			    Texte: <input type="text" name="contenu_a_ajouter" placeholder="Contenu &agrave; ajouter"><br>
			    <input type="submit" value="Enregistrer les modifications" class="btn-enregistrer" >				
			  </form>';
			  
		$_SESSION["ajout"] = $_POST['contenu_a_ajouter'];		 
	}
	
		
	function plugin_handi_init($title){		 
		return $_SESSION["ajout"].$title;
	}
		
}
new HandiPlugin();


	
