
<?php get_header(); ?>  
    <div id="contenu">
	    <hr width="100%">
		<div id="barre-laterale" style="list-style:none; ">        	    
		     <?php dynamic_sidebar('barre_laterale');?>
		</div>
		
		<div id="blog">
		    
			 
		     <?php		 		     
		     while(have_posts()){
		  	         the_post();
		  	?>
		  	         <h2 > <?php the_title(); ?></h2>
		  	         <p><?php the_content(); ?></p>
		  	<?php
		  	     }
		  	?>		     		 
		</div>
	</div>   
   <?php get_footer(); ?>

 

