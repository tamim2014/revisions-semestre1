




    <footer>
    	<div id="essaifooter" >
    		Pied de Page
    	</div>
    	
    </footer>
    <?php wp_footer() ?>

</body>
</html>
