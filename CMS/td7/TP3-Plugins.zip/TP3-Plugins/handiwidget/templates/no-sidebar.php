<?php
/*
Template Name: No Sidebar Template
*/
?>

<?php get_header(); ?>
<div id="contenu">
	<div id="page-no-sidebar"> <!-- VOIR COURS6 page13 -->
		<?php
		  while(have_posts()){
		  	the_post(); ?>
		  	<h2> <?php the_title(); ?> </h2>
		  	<p> Publie par: <?php the_author(); ?>(<?php the_date(); ?>) </p>
		  	<p> <?php the_content(); ?> </p>
		  	<?php

		  }
		?>
		
	</div>
</div>
<?php get_footer(); ?>


