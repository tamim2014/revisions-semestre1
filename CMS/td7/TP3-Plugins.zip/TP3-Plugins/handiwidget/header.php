
<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="utf-8">
	<title>Master Handi Cours de CMS</title>
	<?php wp_head();  ?>
</head>

<body <?php body_class(); ?>>	
	<header>	    
		<div id="en-tete">
           <div id="image-en-tete">
		      <?php the_custom_logo(); ?>
              <img src="<?php header_image() ?>" 
                 height="<?php echo get_custom_header()->height ; ?>"
                 width="<?php echo get_custom_header()->width ; ?>" 
				 style="height:70px; width:92%;"
              />   
		    </div> 		   	  
	    </div>
		<!-- Question4: i fo le sinon on peut pas voir la page no-sidebar.php -->
		<div id="menu" >						
		    <?php 
		        wp_nav_menu(array('theme_location' => 'main_menu')); 
		    ?>			
	    </div>

	</header>

