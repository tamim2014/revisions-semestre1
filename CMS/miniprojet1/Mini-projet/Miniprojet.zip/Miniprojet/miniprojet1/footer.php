    <div class="footer">
        Pied de Page
    </div>
    <?php wp_footer() ?>
    </body>
</html>




