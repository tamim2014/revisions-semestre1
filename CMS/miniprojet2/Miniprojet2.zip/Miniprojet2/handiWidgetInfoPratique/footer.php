<?php session_start(); ?>

	<p>
		 <?php echo $_SESSION["add-footer"];	?>
	</p>

    <div class="footer">
        
    </div>
    <?php wp_footer(); ?>
    </body>
</html>




